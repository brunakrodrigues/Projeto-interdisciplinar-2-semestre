# Projeto Interdisciplinar 2
Projeto realizado no segundo semestre (2019_1)

- Node
- Express
- Mysql
