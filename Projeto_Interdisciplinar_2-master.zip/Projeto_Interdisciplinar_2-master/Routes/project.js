const express = require('express');
const router = express.Router();
const Sql = require("../infra/sql");



module.exports = router;