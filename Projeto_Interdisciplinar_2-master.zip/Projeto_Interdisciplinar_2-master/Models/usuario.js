const Sql = require("../infra/sql");


module.exports = class Usuario {

	

}